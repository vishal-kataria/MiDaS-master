mkdir ~/.ros
wget https://github.com/intel-isl/MiDaS/releases/download/v2_1/model-small-traced.pt
cp ./model-small-traced.pt ~/.ros/model-small-traced.pt


